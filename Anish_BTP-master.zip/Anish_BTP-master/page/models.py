from django.db import models
import os
# Create your models here.
def get_upload_path(instance, filename):
    fileName, fileExtension = os.path.splitext(filename)
    return os.path.join("user.{1}" .format(fileExtension) )

class Document(models.Model):
    result_file=models.FileField(upload_to=get_upload_path)